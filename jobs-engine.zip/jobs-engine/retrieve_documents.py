#############################
#### SI650: Jobs-engine #####
#### Document Retrieval #####
#############################

## import from BM25 package: https://github.com/dorianbrown/rank_bm25
from rank_bm25 import BM25Plus, BM25Okapi, BM25L

import pandas as pd
import sys

from helper_functions import *

# print(sys.argv[1:])

df = pd.read_csv("./data/BM25_DF.csv")

## define corpus from our target data (input should be the string version of the column)
corpus = []

## hardcoding "company_title_entities" to use as corpus for indexing
for i in df["company_title_entities"].values:
    corpus.append(i)

tokenized_corpus = [doc.split(" ") for doc in corpus]

## implement BM25 algo for retrieval
bm25 = BM25L(tokenized_corpus)

## the column variable, make sure it matches with the column that was fitted into BM25 model
query = sys.argv[1]
filters = sys.argv[2]

## implement the function, 
retrieved_documents = retrieve_docs(query=query, corpus=corpus, df=df, bm25=bm25, filters=filters)

## Need to pick the columns we want to return -- TBD
cols_return = ["title", "company", "seniority", "place", "job_function", "employment_type", "link"]
retrieved_documents[cols_return].to_csv("./RETURNED_DOCUMENTS.csv", index=False)
print("Done. Check the generated CSV file for job opportunities. Good luck!")