TO INSTALL DEPENDENCIES USING CONDA --

conda create --name <env> --file requirements.txt

---------

Data is already processed, so no need to run "preprocess_data.py" (as it takes in the FULL_DF.csv file and processes it into the BM25_DF.csv file) 

- If need be, run "python preprocess_data.py", and it will take a while to process. After, retrieve_documents.py can be run successfully. 

IN ORDER TO RUN retrieve_documents.py:

Example -- python retrieve_documents.py "<query>" "<filters>"

Query and filters are strings, hopefully including job title and some skills you may want to include. The filters string will be elements that will be excluded from the results. 

The output is a CSV file with the top 50 job postings. 

Thank you!

