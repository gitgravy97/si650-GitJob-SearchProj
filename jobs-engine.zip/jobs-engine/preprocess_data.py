#############################
#### SI650: Jobs-engine #####
### Data Pre-processing #####
#############################

## import from BM25 package: https://github.com/dorianbrown/rank_bm25
from rank_bm25 import BM25Plus, BM25Okapi, BM25L

import pandas as pd
import nltk
import ast
import string
import spacy

from nltk.stem import PorterStemmer, WordNetLemmatizer
from nltk import sent_tokenize
from nltk import word_tokenize
from nltk import RegexpTokenizer
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize

from helper_functions import *

nltk.download('stopwords')
nltk.download('punkt')
nltk.download('wordnet')

## Loading model (nlp) to pre-process description column later --> DO ENTITY EXTRACTION
nlp = spacy.load("./entity-model/")

### DATA PREPARATION AND FURTHER PRE-PROCESSING
## need to read in FULL_DF to merge and get the description as well
Full_DF = pd.read_csv("./data/FULL_DF.csv")

## description_clean was string of list of strings, use literal_eval to make it list of strings
Full_DF.description_clean = Full_DF.description_clean.apply(lambda x: ast.literal_eval(x))

## assignment of Full_DF to df for proper functioning with our helper functions. Now using full data!
df = Full_DF

### ADDING COLUMNS TO DATAFRAME
## didn't have clean title yet
df["title_clean"] = process_text(df.title)

## make strings out of clean title and description to concatenate
df["title_clean_string"] = [" ".join(i) for i in df.title_clean]
df["description_clean_string"] = [" ".join(i) for i in df.description_clean]

## create a new column with clean title + clean description for "better" retrieval, prolly use BM25L?
df["title_and_description"] = df.title_clean_string + " " + df.description_clean_string

## create an entities column, not clean yet but process the text after probably
print("\nEntity extraction takes a while...")
df["entities"] = df["description"].apply(lambda x: str((nlp(x).ents)).replace("(", "").replace(")", "").replace(",", ""))

## process_text returns a clean list of strings
df["entities_list"] = process_text(df.entities)

## let's make the previous defined list into a clean string for concatenation with title
df["entities_clean_string"] = [" ".join(i) for i in df.entities_list]

## concatenating title and entities (similar to concatenating title and description)
df["title_and_entities"] = df.title_clean_string + " " + df.entities_clean_string

## creating token list for company, and a clean string of company name for concatenation
df["company_token_list"] = process_text(df.company)
df["company_clean_string"] = [" ".join(i) for i in df.company_token_list]

## concatenate company name, job title, and extracted entities
df["company_title_entities"] = df.company_clean_string + " " + df.title_clean_string + " " + df.entities_clean_string

print("\nPre-processed df (BM25_DF.csv) ready to use...")
df.to_csv("./data/BM25_DF.csv", index=False)