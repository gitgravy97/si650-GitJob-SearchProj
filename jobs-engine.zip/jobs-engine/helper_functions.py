########################
## SI650: Jobs-engine ##
### Helper Functions ###
########################

from rank_bm25 import BM25Plus, BM25Okapi, BM25L

import pandas as pd
import nltk
import string
import spacy

from nltk.stem import PorterStemmer, WordNetLemmatizer
from nltk import sent_tokenize
from nltk import word_tokenize
from nltk import RegexpTokenizer
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize

nltk.download('stopwords', quiet=True)
nltk.download('punkt', quiet=True)
nltk.download('wordnet', quiet=True)

def process_text(df_col):
    """
    Helper function to help up process the description columns. Several NLP techniques implemented to get lemmatized, clean tokens
    :input: dataframe column (description)
    :output: list of stemmed, clean tokens
    """
    ret_list = []

    stop_words = set(stopwords.words("english"))

    lemmatizer = WordNetLemmatizer()
    tokenizer = RegexpTokenizer(pattern='\w+|\$[\d\.]+|\S+')

    to_remove = ['show', 'moreshow', 'less']

    for d in df_col:
        ## lowercase text
        text = d.lower()
        ## remove punctuation, keep it as string
        text = "".join([c for c in text if c not in string.punctuation])
        ## tokenization (definitely would use RegExp)
        token_text = tokenizer.tokenize(text)
        ## filter out stopwords
        filt_tokens = [t for t in token_text if t not in stop_words]

        ## get token stems or lemmas? (lemmas seems to have better results, according to below paper)
        # stem_tokens = [stemmer.stem(t) for t in filt_tokens]
        lemma_tokens = [lemmatizer.lemmatize(t) for t in filt_tokens]

        ## removing "show more/less" idiosincracy 
        lemma_tokens = [i for i in lemma_tokens if i not in to_remove]

        # ret_list.append(stem_tokens)
        ret_list.append(lemma_tokens)

    return ret_list

def standard_query(q):
    """
    Similar to description, standardize the query input for appropriate results
    :input: query string
    :output: clean, standardized query string
    """
    stop_words = set(stopwords.words("english"))
    tokenizer = RegexpTokenizer(pattern='\w+|\$[\d\.]+|\S+') 
    # stemmer = PorterStemmer()
    lemmatizer = WordNetLemmatizer()

    # same preprocessing applied in "process_description", but for a given query
    text = q.lower()
    text = "".join([c for c in q if c not in string.punctuation])
    token_text = tokenizer.tokenize(text)
    filt_tokens = [t for t in token_text if t not in stop_words]

    ## stemming or lemmatizing
    # stemmed_query = [stemmer.stem(t) for t in filt_tokens]
    lemmatized_query = [lemmatizer.lemmatize(t) for t in filt_tokens]

    # query_str = " ".join([c for c in stemmed_query])
    query_str = " ".join([c for c in lemmatized_query]).lower()

    return query_str

def query_scores(q, bm25):
    """
    Function to get all the query scores given a query
    :input: query
    :output: document scores for a given query
    """
    stop_words = set(stopwords.words("english"))
    tokenizer = RegexpTokenizer(pattern='\w+|\$[\d\.]+|\S+')
    # stemmer = PorterStemmer()
    lemmatizer = WordNetLemmatizer()

    # same preprocessing applied in "process_description"
    text = q.lower()
    text = "".join([c for c in text if c not in string.punctuation])
    token_text = tokenizer.tokenize(text)
    filt_tokens = [t for t in token_text if t not in stop_words]

    # stemmed_query = [stemmer.stem(t) for t in filt_tokens]
    lemmatized_query = [lemmatizer.lemmatize(t) for t in filt_tokens]

    # get bm25 plus scores
    # doc_scores = bm25.get_scores(stemmed_query)
    doc_scores = bm25.get_scores(lemmatized_query)

    # return sorted(doc_scores, reverse=True)[:10]
    return doc_scores

def top_n_queries(query, corpus, n, bm25, df, column):
    """
    Function to get top N queries, not only scores, but returning the dataframe with our relevant data
    :input: query, corpus, top n
    :output: df subset of entries from our complete df, with a naive relevance score
    """
    query = standard_query(query)
    tokenized_query = query.split(" ")

    top_n = bm25.get_top_n(query, corpus, n=n)
    copy = df.copy()

    # making clean_string column to return nice df of our results
    ### adapted slightly, since now we're gonna find the matching title_and_description, no "clean_string" anymore
    # copy["clean_string"] = copy.description_clean.apply(lambda x: " ".join([i for i in x]))

    # creating simple relevance measure (ground truth) for the given query (if query in description, 1, else 0)
    relevance = []

    for cs in copy[column]:
        if query in cs:
            relevance.append(1)
        else: 
            relevance.append(0)

    copy["in_title"] = relevance

    return copy[copy[column].isin(top_n)]#.reset_index()
    # return copy

def retrieve_docs(query, corpus, df, bm25, **filters):
    """
    Retrieve documents given a query, based on fitted BM25L (could vary algos) --- For this variation, 
    don't need to pick column to return (was for evaluation)
    :input: query string, string of filters to exclude from results
    :output: top 20 postings, alongside mAP evaluation score if set to True -- for final version, just return all postings? just 50
    """
    qq = query

    clean_filters = standard_query(str(list(filters.values())))
    # print(clean_filters)

    ## df with our results, will use to filter out stuff 
    given_query = top_n_queries(qq, corpus, len(df), bm25, df, "company_title_entities")
    given_query["bm25_score"] = query_scores(qq, bm25)

    ## tokenize filter string to exclude from results 
    filter_tokens = word_tokenize(clean_filters)
    # print(filter_tokens) 

    ## making a filter string, delimited by | as OR for multiple filters
    masking_filter_string = (["|".join(filter_tokens)])[0]

    ## filtering our results based on the filter string entered by the user
    ret_df = given_query[~given_query.company_title_entities.str.contains(masking_filter_string)]

    ## now we have all columns available, so pick and choose to get a nice return df --> pick which !!!
    ret_df = ret_df.sort_values(by="bm25_score", ascending=False)[:50]#[['title','ds_rel','security_rel','ux_rel','bm25_score']]

    return ret_df.reset_index(drop=True)

def evaluate_mAP(retrieved_docs, rel_column):
    """
    Function computes mean average precision (mAP) for the given query with ground truth annotations
    ** only for ground truth evaluation, not used in this module.
    :input: retrieved docs df, string of relevant column (either 'ds_rel', 'ux_rel', 'security_rel')
    :output: mAP@20 score for given query
    """
    # for security_docs
    prec_list = []
    relevant_count = 0

    for i, b in enumerate(retrieved_docs[rel_column], 1):
        if b > 0:
            relevant_count += 1
            prec_list.append(relevant_count/i)
            # relevant_count += 1
        if b <= 0:
            prec_list.append(0/i)

    mAP = sum(prec_list) / relevant_count

    # print(prec_list)
    # print(relevant_count)
    return round(mAP, 6)